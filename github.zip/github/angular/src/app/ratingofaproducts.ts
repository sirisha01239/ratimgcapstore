export class Ratingofaproducts {
     public  productId: number;
     public productname: string;
     public  rating: number;
}
