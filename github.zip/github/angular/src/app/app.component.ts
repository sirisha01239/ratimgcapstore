import { Component } from '@angular/core';
import { RatingofaproductsService } from './ratingofaproducts.service';
import { Ratingofaproducts } from './ratingofaproducts';
import {  Input, Output, EventEmitter, OnInit } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ratingofaproducts';

  temp: Ratingofaproducts = new Ratingofaproducts();
constructor(private service: RatingofaproductsService) {}

save(data) {
if ((data.rating>5) || (data.rating<1) ) {
  alert('please  enter valid rating');

} else {
  alert('Thank you');


}

 this.temp.productId = data.productId;
  this.temp.productname = data.productname;
  this.temp.rating = data.rating;
  this.service.addRatingofaproducts(this.temp).subscribe(adata => console.log(adata));
}
}


