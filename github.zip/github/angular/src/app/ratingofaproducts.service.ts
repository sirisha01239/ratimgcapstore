import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Ratingofaproducts } from './ratingofaproducts';

import { Observable } from 'rxjs/internal/Observable';
@Injectable({
  providedIn: 'root'
})
export class RatingofaproductsService {

  constructor(private http: HttpClient) {}
  addRatingofaproducts(data: Ratingofaproducts) {
    return this.http.post('http://localhost:8095/add', data);
}
}
