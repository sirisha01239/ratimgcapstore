package com.capgemini.capstore.controller;

import java.util.List;

import org.json.JSONException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.bean.Ratings;
import com.capgemini.capstore.service.RatingsService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class RatingsController {
    @Autowired
    RatingsService service;
   
    @PostMapping(value="/add",consumes="application/json")
    public void add(@RequestBody Ratings form)
    {
    	service.add(form);
    	//Ratings r1=new Ratings();
    	String productname=form.getProductname();
    	System.out.println("hi");
         
        saveAvgProductRating(productname);
    }

    @GetMapping("/GetAll")
    public List<Ratings> getAll()
    {
         return service.findAll();
    }

    
    @GetMapping(value="/saveAvgProductRating/{productname}")
	public  double  saveAvgProductRating(@PathVariable String productname) {
    	double avgRating=service.getRatingList(productname);
    	List<Ratings> ratings= service.getRatingLists(productname);
    	for(Ratings o: ratings)
    	{
    		o.setAvgRating(avgRating);
    		service.add(o);
    	}
	
    	
    	return service.getRatingList(productname);
	}
 
}
