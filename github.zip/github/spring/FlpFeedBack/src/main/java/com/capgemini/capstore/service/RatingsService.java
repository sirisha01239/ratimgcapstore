package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.capgemini.capstore.bean.Ratings;


public interface RatingsService {
	public void add(Ratings objectForm);
	public List<Ratings> findAll();
	public double getRatingList(String productname);
	public List<Ratings> getRatingLists(String productname);
	
}
