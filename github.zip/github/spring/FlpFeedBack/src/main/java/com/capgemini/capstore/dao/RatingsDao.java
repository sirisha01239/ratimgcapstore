package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.bean.Ratings;

@Repository
public interface RatingsDao extends JpaRepository<Ratings,Integer>  {

	

	
	
	@Query(value="select avg(rating) from Ratings where productname=?1" )
	public double getRatingList(@Param("productname") String productname);
	
	
	@Query(value=" from Ratings where productname=?1" )
	public List<Ratings> getRatingLists(@Param("productname") String productname);
	
	
	

}
