package com.capgemini.capstore.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
//@Table(name = "ratingproduct")
public class Ratings {


	@NotNull
	@Id
	private int productId;
    
	private String productname;
	@Min(value = 1, message = " Rating must be equal or greater than 1")
	@Max(value = 5, message = "Rating must be equal or less than 5")
	@NotNull
	private double rating;
    private double avgRating;
	public double getAvgRating() {
	return avgRating;
}

public void setAvgRating(double avgRating) {
	this.avgRating = avgRating;
}

	public Ratings() {

	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public Ratings(@NotNull int productId, String productname,
			@Min(value = 1, message = " Rating must be equal or greater than 1") @Max(value = 5, message = "Rating must be equal or less than 5") @NotNull int rating) {
		super();
		this.productId = productId;
		this.productname = productname;
		this.rating = rating;
	}
	
}
	
	