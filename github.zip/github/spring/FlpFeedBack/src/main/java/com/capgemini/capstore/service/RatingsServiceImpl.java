package com.capgemini.capstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.bean.Ratings;
import com.capgemini.capstore.dao.RatingsDao;
@Service
public class RatingsServiceImpl implements RatingsService{

	@Autowired
	RatingsDao dao;
	
	@Override
	public void add(Ratings objectForm) {
		// TODO Auto-generated method stub
		
		 dao.save(objectForm);
	}

	@Override
	public List<Ratings> findAll() {
		
		return dao.findAll();	
	}

	@Override
	public double getRatingList(String productname) {
		
		return dao.getRatingList(productname);
	}

	@Override
	public List<Ratings> getRatingLists(String productname) {
		// TODO Auto-generated method stub
		
		return dao.getRatingLists(productname);
	}

	


}
